export function useCart() {
  return {};
}

export function useAuth() {
  return {};
}
